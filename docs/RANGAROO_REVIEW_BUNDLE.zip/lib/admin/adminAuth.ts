import { createServerClient } from '@/lib/supabase/server';
import { NextRequest } from 'next/server';

export type AdminRole =
  | 'SUPER_ADMIN'
  | 'STORE_ADMIN'
  | 'ORDER_MANAGER'
  | 'PRODUCT_MANAGER'
  | 'CONTENT_MANAGER'
  | 'SUPPORT_AGENT';

export type AdminPermission =
  | 'products.read'
  | 'products.manage'
  | 'inventory.read'
  | 'inventory.adjust'
  | 'collections.manage'
  | 'orders.read'
  | 'orders.read_masked'
  | 'orders.fulfill'
  | 'orders.cancel'
  | 'orders.refund'
  | 'customers.read'
  | 'customers.read_masked'
  | 'customers.export'
  | 'coupons.manage'
  | 'campaigns.manage'
  | 'reviews.read'
  | 'reviews.moderate'
  | 'cms.manage'
  | 'shipping.manage'
  | 'staff.manage'
  | 'audit.read'
  | 'settings.manage';

export interface AdminUserRecord {
  id: string;
  email: string;
  full_name: string;
  role: AdminRole;
  is_active: boolean;
  created_at: string;
}

const ROLE_PERMISSIONS: Record<AdminRole, AdminPermission[]> = {
  SUPER_ADMIN: [
    'products.read',
    'products.manage',
    'inventory.read',
    'inventory.adjust',
    'collections.manage',
    'orders.read',
    'orders.read_masked',
    'orders.fulfill',
    'orders.cancel',
    'orders.refund',
    'customers.read',
    'customers.read_masked',
    'customers.export',
    'coupons.manage',
    'campaigns.manage',
    'reviews.read',
    'reviews.moderate',
    'cms.manage',
    'shipping.manage',
    'staff.manage',
    'audit.read',
    'settings.manage',
  ],
  STORE_ADMIN: [
    'products.read',
    'products.manage',
    'inventory.read',
    'inventory.adjust',
    'collections.manage',
    'orders.read',
    'orders.read_masked',
    'orders.fulfill',
    'orders.cancel',
    'orders.refund',
    'customers.read',
    'customers.read_masked',
    'customers.export',
    'coupons.manage',
    'campaigns.manage',
    'reviews.read',
    'reviews.moderate',
    'cms.manage',
    'shipping.manage',
  ],
  ORDER_MANAGER: [
    'products.read',
    'inventory.read',
    'orders.read',
    'orders.read_masked',
    'orders.fulfill',
    'orders.cancel',
    'orders.refund',
    'shipping.manage',
  ],
  PRODUCT_MANAGER: [
    'products.read',
    'products.manage',
    'inventory.read',
    'inventory.adjust',
    'collections.manage',
  ],
  CONTENT_MANAGER: [
    'products.read',
    'cms.manage',
    'reviews.read',
    'reviews.moderate',
    'campaigns.manage',
  ],
  SUPPORT_AGENT: [
    'products.read',
    'orders.read_masked',
    'customers.read_masked',
    'reviews.read',
  ],
};

/**
 * Validates if an authenticated request belongs to an active administrator
 * in the authoritative public.admin_users database table.
 *
 * CRITICAL SECURITY INVARIANT:
 * Never trusts user_metadata (which is client-editable in Supabase).
 * Checks the database record directly to ensure immediate revocation on deactivation.
 */
export async function getAuthoritativeAdminUser(request: NextRequest): Promise<AdminUserRecord | null> {
  try {
    const authHeader = request.headers.get('authorization');
    const supabase = createServerClient();

    let userId: string | null = null;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.replace('Bearer ', '');
      const { data: { user }, error } = await supabase.auth.getUser(token);
      if (user && !error) {
        userId = user.id;
      }
    } else {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (user && !error) {
        userId = user.id;
      }
    }

    if (!userId) {
      return null;
    }

    // Direct lookup in authoritative admin_users table
    const { data: adminRecord, error: dbError } = await supabase
      .from('admin_users')
      .select('id, email, full_name, role, is_active, created_at')
      .eq('id', userId)
      .eq('is_active', true)
      .single();

    if (dbError || !adminRecord) {
      return null;
    }

    return adminRecord as AdminUserRecord;
  } catch {
    return null;
  }
}

/**
 * Checks whether the caller has a specific administrative permission.
 */
export async function hasAdminPermission(
  request: NextRequest,
  permission: AdminPermission
): Promise<boolean> {
  const admin = await getAuthoritativeAdminUser(request);
  if (!admin || !admin.is_active) {
    return false;
  }

  const allowedPermissions = ROLE_PERMISSIONS[admin.role];
  return allowedPermissions ? allowedPermissions.includes(permission) : false;
}

/**
 * Evaluates permission for a given role (useful for unit testing and offline checks).
 */
export function checkRolePermission(role: AdminRole, permission: AdminPermission): boolean {
  const permissions = ROLE_PERMISSIONS[role];
  return permissions ? permissions.includes(permission) : false;
}

/**
 * Masks customer PII for support agent views.
 */
export function maskCustomerPII<T extends { customer_email?: string; customer_phone?: string; customer_name?: string }>(data: T): T {
  const masked = { ...data };

  if (masked.customer_name) {
    masked.customer_name = masked.customer_name.replace(/(\w)\w+/g, '$1***');
  }

  if (masked.customer_email) {
    masked.customer_email = masked.customer_email.replace(
      /^(.)(.*)(@.)(.*)(\..*)$/,
      '$1***$3***$5'
    );
  }

  if (masked.customer_phone) {
    const len = masked.customer_phone.length;
    if (len > 4) {
      masked.customer_phone = masked.customer_phone.slice(0, 3) + ' ***** **' + masked.customer_phone.slice(-3);
    }
  }

  return masked;
}
