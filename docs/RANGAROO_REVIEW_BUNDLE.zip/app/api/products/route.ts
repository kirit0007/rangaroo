import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@/lib/supabase/server';
import { isUserAdmin } from '@/lib/auth/serverAuth';
import { Product } from '@/types';

export async function GET() {
  try {
    const supabase = createServerClient();
    const { data: dbProducts, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && dbProducts && dbProducts.length > 0) {
      const formattedProducts: Product[] = dbProducts.map((row: any) => ({
        id: row.id,
        name: row.name,
        slug: row.slug || row.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        shortDescription: row.short_description || '',
        description: row.description || '',
        price: Number(row.price),
        compareAtPrice: row.compare_at_price ? Number(row.compare_at_price) : undefined,
        categoryId: row.category_id || 'fun-paint-kit',
        collectionId: row.collection_id || 'dinosaur',
        images: typeof row.images === 'string' ? JSON.parse(row.images) : (row.images || ['/logo.png']),
        kitContents: typeof row.kit_contents === 'string' ? JSON.parse(row.kit_contents) : (row.kit_contents || []),
        ageGroup: row.age_group || '5+',
        difficulty: row.difficulty || 'beginner',
        paintType: row.paint_type || 'Tempera (Washable)',
        figureCount: Number(row.figure_count || 1),
        figureSize: row.figure_size || 'medium',
        weightGrams: Number(row.weight_grams || 250),
        stockQuantity: Number(row.stock_quantity || 50),
        isActive: row.is_active !== false,
        isFeatured: row.is_featured === true,
        tags: typeof row.tags === 'string' ? JSON.parse(row.tags) : (row.tags || []),
      }));

      return NextResponse.json({ products: formattedProducts, source: 'supabase' });
    }

    return NextResponse.json({ products: [], source: 'empty' });
  } catch {
    return NextResponse.json({ products: [], source: 'error_fallback' });
  }
}

export async function POST(request: NextRequest) {
  try {
    const isAdmin = await isUserAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized: Admin privileges required' }, { status: 403 });
    }

    const body = await request.json();
    const { product } = body;

    if (!product) {
      return NextResponse.json({ error: 'Product payload required' }, { status: 400 });
    }

    // Upsert into Supabase DB
    const supabase = createServerClient();
    const { error: upsertError } = await supabase.from('products').upsert({
      id: product.id,
      name: product.name,
      slug: product.slug,
      short_description: product.shortDescription,
      description: product.description,
      price: product.price,
      compare_at_price: product.compareAtPrice,
      category_id: product.categoryId,
      collection_id: product.collectionId,
      images: JSON.stringify(product.images),
      kit_contents: JSON.stringify(product.kitContents),
      age_group: product.ageGroup,
      difficulty: product.difficulty,
      paint_type: product.paintType,
      figure_count: product.figureCount,
      figure_size: product.figureSize,
      weight_grams: product.weightGrams,
      stock_quantity: product.stockQuantity,
      is_active: product.isActive,
      is_featured: product.isFeatured,
      tags: JSON.stringify(product.tags),
    });

    if (upsertError) {
      console.error('[Supabase Product Upsert Error]', upsertError);
      return NextResponse.json({ error: upsertError.message || 'Database product upsert failed' }, { status: 500 });
    }

    return NextResponse.json({ success: true, product });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const isAdmin = await isUserAdmin(request);
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized: Admin privileges required' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const productId = searchParams.get('id');

    if (!productId) {
      return NextResponse.json({ error: 'Product ID required' }, { status: 400 });
    }

    const supabase = createServerClient();
    const { error: deleteError } = await supabase.from('products').delete().eq('id', productId);

    if (deleteError) {
      console.error('[Supabase Product Delete Error]', deleteError);
      return NextResponse.json({ error: deleteError.message || 'Database product deletion failed' }, { status: 500 });
    }

    return NextResponse.json({ success: true, productId });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
