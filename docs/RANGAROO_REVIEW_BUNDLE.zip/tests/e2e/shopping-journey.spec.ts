import { test, expect } from '@playwright/test';

test.describe('Storefront Customer Journey & Admin Navigation', () => {
  test('Storefront homepage loads and displays brand elements', async ({ page }) => {
    await page.goto('/');

    // Check title or brand heading
    await expect(page).toHaveTitle(/Rangaroo/i);

    // Verify main content exists
    const main = page.locator('main');
    await expect(main).toBeVisible();
  });

  test('Catalog page lists plaster kit products', async ({ page }) => {
    await page.goto('/products');

    // Verify product grid or main container loads
    await expect(page.locator('main')).toBeVisible();

    // Verify page content loads without 500 error
    const pageText = await page.textContent('body');
    expect(pageText).not.toContain('Internal Server Error');
  });

  test('Admin overview route is protected against unauthenticated direct access', async ({ page }) => {
    const response = await page.goto('/admin');

    // Page must either redirect to login or render admin auth guard
    expect(response?.status()).toBeLessThan(500);
  });
});
